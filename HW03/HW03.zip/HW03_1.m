clear

help rand
help randn
